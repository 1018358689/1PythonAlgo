import random
import copy
cards=[i for i in range(9)] #产生0到8顺序数
print(cards)
i=0
n=len(cards)            #取被取值列表的长度
news=copy.deepcopy(cards)   
while i<n:
    p=random.randint(0,i)
    news[i]=news[p]
    news[p]=cards[i]
    i+=1
print(news)
